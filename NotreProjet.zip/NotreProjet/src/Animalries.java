
public class Animalries {

	public int age ; 
	public String espèce ; 
	public String race ;
	public String sexe;
	public String vaccinations;
	public double prix;
	public String Statut_de_sante;
	public String Descriptrion;
	public String Dated_arrivée ;
	 public Animalries() {}
	 public Animalries(int age ,String espèce,String race, String sexe,String vaccinations,double prix, String Statut_de_sante,String Descriptrion,String Dated_arrivée) 
	 {
		 
		 this.age= age ;
		 this.espèce=espèce;
		 this.race=race;
		 this.sexe=sexe;
		 this.vaccinations=vaccinations;
		 this.prix=prix;
		 this.Statut_de_sante=Statut_de_sante;
		 this.Dated_arrivée=Dated_arrivée;
		 this.Descriptrion=Descriptrion;
		 
	 }
	 
	
	public static void main(String args[]) {
		
		
	}
}

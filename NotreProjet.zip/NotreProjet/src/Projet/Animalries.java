package Projet ;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Animalries implements Comparable<Animalries> {
	

	public String espèce ; 
	public String race ;
	public String sexe;
	public String vaccinations;
	public double prix;
	public String Statut_de_sante;
	public String Descriptrion;
	public String Dated_arrivée ;
	 public Animalries() {}
	 public Animalries(int age ,String espèce,String race, String sexe,String vaccinations,double prix, String Statut_de_sante,String Descriptrion,String Dated_arrivée) 
	 {
		 
		
		 this.espèce=espèce;
		 this.race=race;
		 this.sexe=sexe;
		 this.vaccinations=vaccinations;
		 this.prix=prix;
		 this.Statut_de_sante=Statut_de_sante;
		 this.Dated_arrivée=Dated_arrivée;
		 this.Descriptrion=Descriptrion;
		 
	 }
	 @Override
	    public String toString() {
	        return "Animalerie{" +
	                "espèce='" + espèce + '\'' +
	                ", race=" + race +"sexe=" + sexe +"vaccinations="+ vaccinations+"prix"+prix+"Statut_de_sante"+Statut_de_sante+
	                "Descriptrion"+Descriptrion +"Dated_arrivée"+Dated_arrivée+
	                '}';
	    }
	 @Override
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        Animalries that = (Animalries) obj;
	        return Double.compare(that.prix, prix) == 0 &&
	                espèce.equals(that.espèce) &&
	                race.equals(that.race) &&
	                sexe.equals(that.sexe) &&
	                vaccinations.equals(that.vaccinations) &&
	                Statut_de_sante.equals(that.Statut_de_sante) &&
	                Descriptrion.equals(that.Descriptrion) &&
	                Dated_arrivée.equals(that.Dated_arrivée);
	    }
	 @Override
	    public Object clone() {
	        try {
	            return super.clone();
	        } catch (CloneNotSupportedException e) {
	            throw new RuntimeException(e);
	        }
	    }
	 
	    public int compareTo(Animalries autreAnimal) {
	       
	        return Double.compare(this.prix, autreAnimal.prix);
	    }
	
	   
	    public static void main(String[] args) {
	        List<Animalries> animalList = new ArrayList<>();
	        
	        Collections.sort(animalList);

	        
	        for (Animalries animal : animalList) {
	            System.out.println(animal);
	        }
	    }
}


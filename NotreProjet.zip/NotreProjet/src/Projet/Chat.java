package Projet;

public class Chat {

	public int age ; 
	public String type ; 
	public String reference ;
	public Chat() {}
	public Chat(int age ,String type,String reference)
	{
		
		 this.age=age;
		 this.type=type;
		 this.reference=reference;

		 
	}
	
}


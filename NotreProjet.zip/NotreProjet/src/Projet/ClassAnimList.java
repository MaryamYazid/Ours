package Projet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ClassAnimList {

	private Animalries[] tablepersonne;
	 private List<Animalries> animalriesList;

	    public ClassAnimList() {
	        this.animalriesList = new ArrayList<>();
	    }

	   
	    public void alimenterListe(Animalries animalries) {
	        animalriesList.add(animalries);
	    }

	  
	    @Override
	    public String toString() {
	        return "ClassAnimList{" +
	                "animalriesList=" + animalriesList +
	                '}';
	    }
	    public void afficherListe() {
	        for (Animalries animalries : animalriesList) {
	            System.out.println(animalries);
	        }
	    }

	     public void parcourirAvecIterateur() {
	        Iterator<Animalries> iterator = animalriesList.iterator();
	        while (iterator.hasNext()) {
	            Animalries animalries = iterator.next();
	            System.out.println(animalries);
	        }
	    }
	     public void insererElement(int position, Animalries animalries) {
	         if (position >= 0 && position <= animalriesList.size()) {
	             animalriesList.add(position, animalries);
	         } else {
	             System.out.println("Position invalide pour l'insertion.");
	         }
	     }

	     public Animalries recupererElement(int position) {
	         if (position >= 0 && position < animalriesList.size()) {
	             return animalriesList.get(position);
	         } else {
	             System.out.println("Position invalide pour la récupération.");
	             return null;
	         }
	     }

	     public void supprimerElement(int position) {
	         if (position >= 0 && position < animalriesList.size()) {
	             animalriesList.remove(position);
	         } else {
	             System.out.println("Position invalide pour la suppression.");
	         }
	     }

	     public boolean rechercherElement(Animalries animalries) {
	         return animalriesList.contains(animalries);
	     }

	     public void trierListe() {
	         Collections.sort(animalriesList);
	     }

	     public List<Animalries> copierListe() {
	         return new ArrayList<>(animalriesList);
	     }


	     public void melangerListe() {
	         Collections.shuffle(animalriesList);
	     }

	     // Fonction pour inverser les éléments de la liste
	     public void inverserListe() {
	         Collections.reverse(animalriesList);
	     }

	     // Fonction pour extraire une partie de la liste
	     public List<Animalries> extrairePartieListe(int debut, int fin) {
	         if (debut >= 0 && fin <= animalriesList.size() && debut <= fin) {
	             return new ArrayList<>(animalriesList.subList(debut, fin));
	         } else {
	             System.out.println("Indices de début ou de fin invalides.");
	             return null;
	         }
	     }

	     public boolean comparerListes(List<Animalries> autreListe) {
	         return animalriesList.equals(autreListe);
	     }

	     public void echangerElements(int indice1, int indice2) {
	         if (indice1 >= 0 && indice1 < animalriesList.size() &&
	             indice2 >= 0 && indice2 < animalriesList.size()) {
	             Collections.swap(animalriesList, indice1, indice2);
	         } else {
	             System.out.println("Indices d'échange invalides.");
	         }
	     }

	     public void viderListe() {
	         animalriesList.clear();
	     }

	     public boolean estVide() {
	         return animalriesList.isEmpty();
	     }

	    public static void main(String[] args) {
	       
	        ClassAnimList classAnimList = new ClassAnimList();

	       
	        Animalries animal1 = new Animalries(/* ... */);
	        Animalries animal2 = new Animalries(/* ... */);

	        classAnimList.alimenterListe(animal1);
	        classAnimList.alimenterListe(animal2);

	        
	        System.out.println(classAnimList);
	        System.out.println("Parcours de la liste avec un itérateur:");
	        classAnimList.parcourirAvecIterateur();
	    
	    
	    classAnimList.insererElement(1, new Animalries(/* ... */));

        System.out.println("Élément à la position 0: " + classAnimList.recupererElement(0));

        classAnimList.supprimerElement(2);

        System.out.println("Recherche de l'élément: " + classAnimList.rechercherElement(animal1));

        classAnimList.trierListe();

        List<Animalries> copieListe = classAnimList.copierListe();
        System.out.println("Copie de la liste dans un nouveau tableau:");
        for (Animalries animal : copieListe) {
            System.out.println(animal);
            
            ClassAnimList autreListe = new ClassAnimList();
            autreListe.alimenterListe(animal1);
            autreListe.alimenterListe(animal2);
            System.out.println("Comparaison des listes: " + classAnimList.comparerListes(autreListe.animalriesList));

            classAnimList.echangerElements(0, 1);

            classAnimList.viderListe();

            System.out.println("La liste est vide : " + classAnimList.estVide());
        
        }
	    }
}

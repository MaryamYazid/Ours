package Projet;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
public class tableauAnimalries {

	private Animalries[] tableauAnimalries;

    public tableauAnimalries(Animalries[] tableauAnimalries) {
        this.tableauAnimalries = tableauAnimalries;
    }
    
    public tableauAnimalries(int taille) {
        this.tableauAnimalries = new Animalries[taille];
    }

    
    public void trierParPrix() {
        Arrays.sort(tableauAnimalries);
    }

    public void ajouterAnimalries(Animalries animalries) {
       
        for (int i = 0; i < tableauAnimalries.length; i++) {
            if (tableauAnimalries[i] == null) {
                tableauAnimalries[i] = animalries;
                return; 
            }
        }
    }
    public void supprimerAnimalries(Animalries animalries) {
        for (int i = 0; i < tableauAnimalries.length; i++) {
            if (tableauAnimalries[i] != null && tableauAnimalries[i].equals(animalries)) {
                tableauAnimalries[i] = null;
                return; 
            }
        }
    }
    public Animalries[] getTableauAnimalries() {
        return tableauAnimalries;
    }

    public void setTableauAnimalries(Animalries[] tableauAnimalries) {
        this.tableauAnimalries = tableauAnimalries;
    }

    @Override
    public String toString() {
        return "TableauAnimalries{" +
                "tableauAnimalries=" + Arrays.toString(tableauAnimalries) +
                '}';
    }
    
    public int nombreElements() {
        int count = 0;
        for (Animalries animalries : tableauAnimalries) {
            if (animalries != null) {
                count++;
            }
        }
        return count;

    }
    public void inverserOrdre() {
        Collections.reverse(Arrays.asList(tableauAnimalries));
    }

   
    public void afficherTableau() {
        for (Animalries animalries : tableauAnimalries) {
            System.out.println(animalries);
        }
    }

   
    public Animalries getElementPlusGrand() {
        Animalries maxElement = null;
        for (Animalries animalries : tableauAnimalries) {
            if (animalries != null && (maxElement == null || animalries.compareTo(maxElement) > 0)) {
                maxElement = animalries;
            }
        }
        return maxElement;
    }
 
    public static void main(String[] args) {
        
    }

}

